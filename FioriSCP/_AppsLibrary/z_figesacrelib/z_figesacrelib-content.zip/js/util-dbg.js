var TRATAMIENTO = [
	{ANRED:'0001',ANRED_DESC:'Sra.'},
	{ANRED:'0002',ANRED_DESC:'Sr.'},
	{ANRED:'0003',ANRED_DESC:'Empresa'},
	{ANRED:'0004',ANRED_DESC:'Señores'},
	{ANRED:'0005',ANRED_DESC:'Estimados'},
	{ANRED:'0006',ANRED_DESC:'Persona Natural'},
	{ANRED:'0007',ANRED_DESC:'Persona Jurídica'},
	{ANRED:'0008',ANRED_DESC:'Fondo de Inversión'}];