var oDataPath 	= "/FioriSCP.z_figesacrelib/sap/opu/odata/sap/ZODATA_FI_GEST_ACREEDOR_LIB_SRV/";
var serviceUrlLib 		= oDataPath;
var oDataPathConsulta 	= "/FioriSCP.z_figesacrelib/sap/opu/odata/sap/ZODATA_FI_GESTION_ACREEDORES_SRV/";
var serviceUrlConsultaLib 		= oDataPathConsulta;