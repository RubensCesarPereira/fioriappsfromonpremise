sap.ui.define([
	"conchaytoro/cl/zsd_crear_merma/test/unit/controller/View1.controller"
], function () {
	"use strict";
});