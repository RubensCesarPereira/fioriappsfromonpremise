sap.ui.define([
	"cl/conchaytoro/zpp_descomponer_mezcla/test/unit/controller/View1.controller"
], function () {
	"use strict";
});