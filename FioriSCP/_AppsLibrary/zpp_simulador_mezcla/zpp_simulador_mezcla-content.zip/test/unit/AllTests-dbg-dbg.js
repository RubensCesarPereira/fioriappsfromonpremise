sap.ui.define([
	"cl/conchaytoro/zpp_simulador_mezcla/zpp_simulador_mezcla/test/unit/controller/View1.controller"
], function () {
	"use strict";
});