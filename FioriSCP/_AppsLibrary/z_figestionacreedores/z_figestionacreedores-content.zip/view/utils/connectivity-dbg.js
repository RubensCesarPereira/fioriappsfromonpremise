var oDataPath 	= "/FioriSCP.z_figestionacreedores/sap/opu/odata/sap/ZODATA_FI_GESTION_ACREEDORES_SRV/";
//var oDataPath = "proxy/sap/opu/odata/sap/ZODATA_FI_GESTION_ACREEDORES_SRV/";
var serviceUrl 		= oDataPath;
