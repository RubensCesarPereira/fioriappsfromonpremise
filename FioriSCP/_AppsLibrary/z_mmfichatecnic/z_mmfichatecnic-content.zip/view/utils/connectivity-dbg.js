var oDataPath 	= "/FioriSCP.z_mmfichatecnic/sap/opu/odata/sap/ZODATA_MM_FICHA_TEC_ENOLOGICA_SRV/";
//var oDataPath = "proxy/sap/opu/odata/sap/ZODATA_MM_FICHA_TEC_ENOLOGICA_SRV/";
var serviceUrl 		= oDataPath;
