sap.ui.define([
	"conchaytoro/cl/zsd_crear_solicitud_vino/test/unit/controller/View1.controller"
], function () {
	"use strict";
});