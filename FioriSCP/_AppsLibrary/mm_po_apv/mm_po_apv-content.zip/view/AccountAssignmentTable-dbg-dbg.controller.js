/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */

sap.ui.controller("ui.s2p.mm.purchorder.approve.view.AccountAssignmentTable", {

    onInit: function() {

    }

});

