sap.ui.define([
	"cl/conchaytoro/zpp_crea_reclasificacion/test/unit/controller/View1.controller"
], function () {
	"use strict";
});