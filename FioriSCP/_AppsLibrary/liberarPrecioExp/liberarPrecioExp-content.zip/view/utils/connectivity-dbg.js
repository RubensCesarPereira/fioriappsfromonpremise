var oDataPath 	= "/FioriSCP.liberarPrecioExp/sap/opu/odata/sap/ZODATA_SD_LIB_PRECIOS_EXPORT_SRV/";
//var oDataPath 	= "proxy/sap/opu/odata/sap/ZODATA_SD_LIB_PRECIOS_EXPORT_SRV/";
var serviceUrl 		= oDataPath;
