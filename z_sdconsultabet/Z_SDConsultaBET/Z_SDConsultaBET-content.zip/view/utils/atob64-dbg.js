		var string = 'Hello World!';
		// Encode the String
		var encodedString = btoa(string);
		console.log(encodedString); // Outputs: "SGVsbG8gV29ybGQh"
		// Decode the String
		var param = "Zj0xJnQ9MTAwMCZkPTIwMTgxMDEw";